package twix.gui;

public abstract class Presentation {

    protected Screens config;

    public Presentation(Screens config) {
        this.config = config;
    }
}
